# TODO: Enlever le pass et définir la class Post qui contient les 3 attributs suivants:
# username
# content
# postDate
from ast import Pass
from xml.dom.pulldom import PROCESSING_INSTRUCTION


class Post:
    def __init__(self, username, post, posteDate) -> None:
        self.username = username
        self.post = post
        self.postDate = posteDate

    def username (self):
        usernames = self.readUsers()
        username = [x for x in usernames if x.username == username]
        




